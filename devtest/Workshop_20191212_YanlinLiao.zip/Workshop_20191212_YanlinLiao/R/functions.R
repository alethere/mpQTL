#' convert PedigreeSim format to Mode of inheritance test format 
#'
#' @param dosages Pedigreesim simulated multi-allelic marker format. Markers as row, individuals as column.
#' @param ploidy crop ploidy level
#' @param Parent1 the column name of parent 1
#' @param Parent2 the column name of parent 2
#' @param filter_ind the individuals you would like to filter out. If there is nothing, please use NULL
#' @param individuals F1 individuals column name for this F1 population
#'
#' @return formatted list of each haploblock (temp, parent)
#' @export
#'
#' @examples
format_Pedigreesim_MMtest <- function(dosages = poly_dosages,ploidy = 4,Parent1,Parent2,
                                      filter_ind = ind_filter,individuals){
  mrk_name <- as.character(unique(dosages$marker))
  A <- lapply(mrk_name,function(mrk){
    # print(mrk)
    temp <- dosages[dosages$marker %in% mrk,]
    temp <- temp[,c('marker','allele',Parent1,Parent2,individuals)]
    
    #identify the NA
    NA_col <- names(which(colSums(is.na(temp[,-c(1,2)])) > 0))
    non_NA <- names(which(colSums(is.na(temp[,-c(1,2)])) == 0))
    
    #non NA part
    temp_nonNA <- temp[,non_NA,drop = FALSE]
    class <- as.character(temp$allele)
    if(ncol(temp_nonNA) > 0){
      temp_convert <- as.data.frame(t(sapply(1:ncol(temp_nonNA),function(j){
        unlist(sapply(1:nrow(temp_nonNA),function(i){
          if(!is.na(temp_nonNA[i,j])){
            replicate(temp_nonNA[i,j],class[i])
          }
        }))
      })))
      rownames(temp_convert) <- colnames(temp_nonNA)
    }else{
      temp_convert <- NULL
    }
    
    
    
    #missing part
    temp_missing <- matrix(nrow = length(NA_col),ncol = ploidy)
    rownames(temp_missing) <- NA_col
    colnames(temp_missing) <- colnames(temp_convert)
    #fill possibly not all missing
    # if(length(NA_col) > 0){
    #   if(colSums(!is.na(temp[,NA_col,drop = FALSE])) > 0){
    #     writeLines(paste0('Please check ',mrk))
    #   }
    # }
    
    temp_res <- rbind(temp_convert,temp_missing)
    temp_res <- temp_res[colnames(temp)[3:ncol(temp)],]
    
    
    format_list <- list()
    format_list[["parent_info"]] <- temp_res[c(Parent1,Parent2),]
    format_list[["temp"]] <- temp_res[!rownames(temp_res) %in% filter_ind,]
    format_list
  })
  names(A) <- mrk_name
  return(A)
}


#' convert polyhaplotyper's format to Mode of inheritance test format
#'
#' @param haplotype_list haplotype list created by polyhaplotyper
#' @param ploidy ploidy level
#' @param Parent1 column name of parent 1 in polyhaplotyper's result- hapdos
#' @param Parent2 column name of parent 2 in polyhaplotyper's result- hapdos
#' @param individuals F1 individuals column name for this F1 population
#' @param filter_ind the individuals you would like to filter out. If there is nothing, please use NULL
#'
#' @return formatted list of each haploblock (temp, parent)
#' @export
#'
#' @examples
format_polyhaplotyper_MMtest <- function(haplotype_list = result_total,
                                         ploidy = 4,
                                         Parent1 = 'P1',
                                         Parent2 = 'P2',
                                         individuals = individuals,
                                         filter_ind = ind_filter){
  if("plyr" %in% rownames(installed.packages())){
    library(plyr)
  }else{
    install.packages('plyr')
    library(plyr)
  }
  
  #convert res to PedigreeSim format
  multi_temp <- do.call(rbind,lapply(names(haplotype_list),function(contig_nme){
    # print(contig_nme)
    haptable <- haplotype_list[[contig_nme]]$hapdos
    haptable <- as.data.frame(haptable)
    
    if(nrow(haptable) > 0){
      haptable$allele <- LETTERS[seq_along(rownames(haptable))]
      haptable$marker <- contig_nme
      rownames(haptable) <- NULL
    }
    haptable
  }))
  col_len <- ncol(multi_temp)
  multi_temp <- multi_temp[,c(col_len,(col_len-1),1:(col_len-2))]
  #convert to Mode test format
  res <- format_Pedigreesim_MMtest(dosages = multi_temp,ploidy = ploidy,Parent1 = Parent1,Parent2 = Parent2,individuals = individuals,
                                   filter_ind = filter_ind)
  return(res)
}

#' each haploblock inheritance identification
#'
#' @param pair parent multi-allelic marker formation. In the format of ABCD_EFGH
#' @param F1 offspring's multi-allelic marker. It is a dataframe using marker names as row. The column does not represent the phasing
#' @param seg_invalidrate threshold used to alow the proportion of unexpected marker segregation in the whole non-missing population
#'
#' @return a list contain both P1 and P2's polysomic and all possibilities of disomic inheritance's test results
#' @export
#'
#' @examples
Pair_count_segregation <- function(pair,
                                   F1 = offspring_score,
                                   seg_invalidrate = 0.05){
  check_seg_pro <- function(gametes,F1,parent){
    gametes <- unique(gametes)
    parent_col <- paste0(parent,"_",seq(1,2))
    
    F1 <- F1[complete.cases(F1),] #remove missing individual
    F1[,parent_col] <- t(apply(F1[,parent_col],1,sort))
    F1 <- apply(F1,2,as.character)
    sapply(gametes,function(i){
      allele <- strsplit(i,'')[[1]]
      
      sum(ifelse(sapply(1:nrow(F1),function(j){
        sum(F1[j,parent_col] == sort(allele))
      }) == 2,1,0) * as.numeric(F1[,'probability']))
      
    })
  } #for observarion
  
  #check segregation and obtain the P value
  segregation_fit <- function(possible_gamete = P1_gamete_diso,
                              parent = 'P1',
                              probability_offspring = Total$Disomic,
                              seg_invalidrate,
                              missing_nbr){
    temp <- lapply(names(probability_offspring),function(i){
      parent_pairing <- strsplit(i,'_')[[1]][as.numeric(gsub('P','',parent))]
      exp <- table(possible_gamete$gamete[[parent_pairing]])
      #remove missing
      parent_col <- paste0(parent,"_",seq(1,2))
      offspring_temp <- probability_offspring[[i]]
      parent_temp <- offspring_temp[,parent_col]
      
      valid_temp <- offspring_temp[complete.cases(offspring_temp),]
      valid_ind <- sum(as.numeric(valid_temp$probability))
      # print(i)
      # print(nrow(F1) - valid_ind - missing_nbr)
      
      # missing_ratio <- (length(unique(offspring_temp$individual)) - valid_ind)/
      # length(unique(offspring_temp$individual)) ##think about this
      
      if(valid_ind > 10){#if there are at least 10 individuals
        obs <- check_seg_pro(gametes = possible_gamete$gamete[[parent_pairing]],F1 = offspring_temp,parent = parent)
        obs <- obs[names(exp)]
        invalidP <- pbinom(q= sum(obs),   #nr of valid counts
                           size= length(unique(offspring_temp$individual)) - missing_nbr, #total individuals
                           # size= valid_ind, 
                           prob=1 - seg_invalidrate) 
        if (length(exp) == 1) {
          p_chi <- 1
        } else {
          if (sum(obs) == 0) {
            #all observations are in invalid classes
            p_chi <- 0.0
            invalidP <- 0.0
          } else {
            test <-  suppressWarnings(chisq.test(obs,p = exp/sum(exp)))
            p_chi <- test$p.value
          }
        }
      }else{
        p_chi <- NA
        invalidP <- NA
        obs <- NA
      }
      
      list('score'=round(p_chi * invalidP,2),
           'observed_count' = obs,
           'expected_count' = round(exp/sum(exp),2),
           'invalid%' = round((length(unique(offspring_temp$individual)) - sum(obs))/length(unique(offspring_temp$individual)),2))
      
    })
    names(temp) <- names(probability_offspring)
    return(temp)
  }
  
  P1 <- strsplit(pair,'_')[[1]][1]
  P2 <- strsplit(pair,'_')[[1]][2]
  
  #a list include the frequency of the gamete pair and the possible gamete for P1 under polysomic inheritance
  P1_gamete_poly <- create_gamete_polysomic(parent = P1) 
  P2_gamete_poly <- create_gamete_polysomic(parent = P2)
  
  P1_gamete_diso <- create_gamete_disomic(parent = P1)
  P2_gamete_diso <- create_gamete_disomic(parent = P2)
  
  
  poly_theoratical <- create_offspring(P1_gamete = P1_gamete_poly,
                                       P2_gamete = P2_gamete_poly)
  diso_theoratical <- create_offspring(P1_gamete = P1_gamete_diso,
                                       P2_gamete = P2_gamete_diso)
  
  ###Calculate offspring probability score of where it obtained from parents
  Total <- gamete_probability_calcultion(F1 = F1,
                                         P1,
                                         P2)
  missing_nbr <- sum(!complete.cases(F1)) #true missing nbr from F1
  
  
  ####chisquare test fitting with expected pair count
  result <- list()
  result[['P1']][['diso']] <- segregation_fit(possible_gamete = P1_gamete_diso,
                                              parent = 'P1',
                                              probability_offspring = Total$Disomic,
                                              seg_invalidrate,
                                              missing_nbr = missing_nbr)
  result[['P2']][['diso']] <- segregation_fit(possible_gamete = P2_gamete_diso,
                                              parent = 'P2',
                                              probability_offspring = Total$Disomic,
                                              seg_invalidrate,
                                              missing_nbr = missing_nbr)
  result[['P1']][['poly']] <- segregation_fit(possible_gamete = P1_gamete_poly,
                                              parent = 'P1',
                                              probability_offspring = Total$Polysomic,
                                              seg_invalidrate,
                                              missing_nbr = missing_nbr)
  result[['P2']][['poly']] <- segregation_fit(possible_gamete = P2_gamete_poly,
                                              parent = 'P2',
                                              probability_offspring = Total$Polysomic,
                                              seg_invalidrate,
                                              missing_nbr = missing_nbr)
  return(result)
} 


#' generate the polysomic inheritance gametes
#'
#' @param parent one parent's multi-allelic marker, e.g. AAAC
#'
#' @return all possible gametes under polysomic inheritance
#' @export
#'
#' @examples
create_gamete_polysomic <- function(parent = P1){ #parent:'AAAC'
  allele <- strsplit(parent,'')[[1]]
  gamete_matrix <- combn(allele,2)
  gamete <- list(sapply(1:ncol(gamete_matrix),function(i){
    paste0(gamete_matrix[,i],collapse = '')
  }))
  names(gamete) <- parent
  frequency <- table(names(gamete))
  frequency <- frequency/sum(frequency)
  result_list <- gamete[names(frequency)]
  return(list('frequency' = frequency,
              'gamete' = result_list))
}

#' generate the disomic inheritance gametes under all situations
#'
#' @param parent one parent's multi-allelic marker, e.g. AAAC
#'
#' @return all possible gametes under disomic inheritance of all possibility situations
#' @export
#'
#' @examples
create_gamete_disomic <- function(parent = P1){
  allele <- strsplit(parent,'')[[1]]
  gamete_matrix <- combn(allele,2)
  left_side <- gamete_matrix[,1:3]
  right_side <- gamete_matrix[,6:4]
  # combine <- cbind(t(left_side),t(right_side))
  # combine_u <- unique(combine)
  possible_list <- lapply(1:ncol(left_side),function(i){
    possibility <- expand.grid(left_side[,i],right_side[,i])
    possibility <- t(apply(possibility,1,sort))
    possibility <- apply(possibility,2,as.character)
    paste0(possibility[,1],possibility[,2])
  })
  names(possible_list) <- paste(do.call(paste0, as.data.frame(t(left_side))),
                                do.call(paste0, as.data.frame(t(right_side))),sep = '|')
  
  frequency <- table(names(possible_list))
  frequency <- frequency/sum(frequency)
  result_list <- possible_list[names(frequency)]
  return(list('frequency' = frequency,
              'gamete' = result_list))
}

#' based on the possible gamete from both parent, what is the possible offspring genotype 
#'
#' @param P1_gamete parent 1's all possible gametes
#' @param P2_gamete parent 2's all possible gametes
#'
#' @return offspring's all possible genotypes 
#' @export
#'
#' @examples
create_offspring <- function(P1_gamete = P1_gamete_diso,
                             P2_gamete = P2_gamete_diso){
  final_comb <- list()
  for(i in seq(1,length(P1_gamete[['gamete']]))){
    for(j in seq(1,length(P2_gamete[['gamete']]))){
      possible_combinations <- expand.grid(P1_gamete[['gamete']][[i]],P2_gamete[['gamete']][[j]])
      possible_combinations <- apply(possible_combinations,2,as.character)
      possible_comb <- sapply(1:nrow(possible_combinations),function(n){
        paste0(sort(c(strsplit(possible_combinations[n,1],'')[[1]],
                      strsplit(possible_combinations[n,2],'')[[1]])),
               collapse = '')})
      freq <- as.numeric(P1_gamete[['frequency']][i] * P2_gamete[['frequency']][j])
      # comb_name <- paste(names(P1_gamete[['gamete']])[i],names(P2_gamete[['gamete']])[j],sep = '_')
      result <- list()
      result[['frequency']] <- freq
      result[['possible_comb']] <- possible_comb
      final_comb[[paste(names(P1_gamete[['gamete']])[i],names(P2_gamete[['gamete']])[j],sep = '_')]] <- result
    }
  }
  return(final_comb)
}


#' generate the probability of each offspring's genotype 
#'
#' @param F1 dataframe of offspring's multi-allelic marker genotype
#' @param P1 parent1's genotype
#' @param P2 parent2's genotype
#' @param ploidy ploidy level
#'
#' @return a dataframe include each offspring's genotype probability under different mode of inheritance 
#' @export
#'
#' @examples
gamete_probability_calcultion <- function(F1 = offspring_score,
                                          P1,
                                          P2,
                                          ploidy = 4){
  found_probability <- function(P1,
                                P2,
                                inheritance,
                                row = F1[i,],
                                ind_nme = F1_ind[i]){
    if(inheritance == 'Polysomic'){
      P1_gamete <- create_gamete_polysomic(parent = P1) 
      P2_gamete <- create_gamete_polysomic(parent = P2)
    }else{
      P1_gamete <- create_gamete_disomic(parent = P1)
      P2_gamete <- create_gamete_disomic(parent = P2)
    }
    result_temp <- list()
    for(parent1 in names(P1_gamete$gamete)){
      for(parent2 in names(P2_gamete$gamete)){
        P1_G <- P1_gamete$gamete[[parent1]]
        P2_G <- P2_gamete$gamete[[parent2]]
        
        P1_pass <- t(matrix(unlist(strsplit(P1_G,'')),2))
        P2_pass <- t(matrix(unlist(strsplit(P2_G,'')),2))
        
        result <- as.data.frame(do.call(rbind,lapply(1:nrow(P1_pass),function(i){
          do.call(rbind,lapply(1:nrow(P2_pass),function(j){
            possible <- c(as.character(P1_pass[i,]),as.character(P2_pass[j,]))
            #in case if row is all NA
            if(all(is.na(row))){
              result <- row
            }else{
              if(all(sort(possible) == sort(row))) possible
            }
          }))})))
        if(nrow(result) > 0){
          result <- plyr::count(result,vars = c('V1','V2','V3','V4'))
          result$individual <- ind_nme
          result$pairing <- paste0(parent1,'_',parent2)
          result$pair_freq <- P1_gamete$frequency[parent1] * P2_gamete$frequency[parent2]
          result <- result[,c(6,1:5,7:8)]
          colnames(result) <- c('individual','P1_1','P1_2','P2_1','P2_2','probability','pairing','pair_freq')
          result$probability <- result$probability/sum(result$probability)
          result <- apply(result,2,as.character)
          result_temp[[paste0(parent1,'_',parent2)]] <- result
        }
      }
    }
    result_tmp <- as.data.frame(do.call('rbind',result_temp),stringsAsFactors = FALSE)
    rownames(result_tmp) <- NULL
    return(result_tmp)
  }
  format_pairint_list <- function(temp = poly_total){
    final_list <- list()
    for(pair in unique(temp$pairing)){
      df <- temp[temp$pairing %in% pair,]
      not_appearing_ind <- setdiff(F1_ind,unique(df$individual))
      if(length(not_appearing_ind) > 0){
        df2 <- as.data.frame(matrix(ncol = ncol(df),nrow = length(not_appearing_ind)),stringsAsFactors = FALSE)
        colnames(df2) <- colnames(df)
        df2$individual <- not_appearing_ind
        df2$pairing <- pair
        df2$pair_freq <- unique(df$pair_freq)
        df <- rbind(df,df2)
      }
      final_list[[pair]] <- df
    }
    return(final_list)
  }
  
  F1_ind <- rownames(F1)
  F1 <- apply(F1,2,as.character)
  
  poly_total <- data.frame();diso_total <- data.frame()
  for(i in 1:nrow(F1)){
    # print(i)
    #polysomic
    poly_temp <- found_probability (P1,
                                    P2,
                                    inheritance = 'Polysomic',
                                    row = F1[i,],
                                    ind_nme = F1_ind[i])
    #disomic
    diso_temp <- found_probability (P1,
                                    P2,
                                    inheritance = 'Disomic',
                                    row = F1[i,],
                                    ind_nme = F1_ind[i])
    
    poly_total <- rbind(poly_total,poly_temp)
    diso_total <- rbind(diso_total,diso_temp)
    
    
    
    
    
    #OLD VERSION
    # row_count <- table(row)
    # parents_count <- table(c(strsplit(P1,'')[[1]],strsplit(P2,'')[[1]]))
    # parents_count <- parents_count[names(row_count)]
    # if(!all(is.na(row))&
    #    (sum(strsplit(P1,'')[[1]] %in% row) >= ploidy/2) & (sum(strsplit(P2,'')[[1]] %in% row) >= ploidy/2) &
    #    all(parents_count >= row_count)){
    #   P1_hap <- strsplit(P1,'')[[1]] ; P2_hap <- strsplit(P2,'')[[1]]
    #   P1_possible_gamete <- P1_hap[P1_hap %in% row]; P2_possible_gamete <- P2_hap[P2_hap %in% row]
    #   # P1_pass <- unique(t(combn(P1_possible_gamete,2))); P2_pass <- unique(t(combn(P2_possible_gamete,2)))
    #   P1_pass <- t(combn(P1_possible_gamete,2)); P2_pass <- t(combn(P2_possible_gamete,2))
    #   
    #   result <- do.call(rbind,lapply(1:nrow(P1_pass),function(i){
    #     do.call(rbind,lapply(1:nrow(P2_pass),function(j){
    #       c(as.character(P1_pass[i,]),as.character(P2_pass[j,]))
    #     }))
    #   }))
    #   
    #   result <- data.frame(F1_ind[i],do.call(rbind,lapply(1:nrow(result),function(i){
    #     if(all(sort(result[i,]) == sort(row))) result[i,]
    #   })))
    #   colnames(result) <- c('individual','P1_1','P1_2','P2_1','P2_2')
    # }else{
    # 
    #  
    #   
    #   result <- matrix(nrow = 1,ncol = ploidy + 1)
    #   result[1,1] <- F1_ind[i]
    #   colnames(result) <- c('individual','P1_1','P1_2','P2_1','P2_2')
    #   result <- as.data.frame(result)
    # }
    # result$probability <- replicate(nrow(result),1/nrow(result))
    
    
    # sharing <- sum(P1_hap %in% P2_hap)
    # sharing_element <- P1_hap[P1_hap %in% P2_hap]
    # 
    # P1_possible_gamete <- P1_hap[P1_hap %in% row]
    # P1_pass <- t(as.matrix(P1_possible_gamete[!P1_possible_gamete %in% sharing_element]))
    # if(length(P1_pass) == 0 & length(unique(P1_possible_gamete))== 1) P1_pass <- t(as.matrix(P1_possible_gamete[1:2]))
    # if(length(P1_pass) != 2 & length(P1_pass) != 0){
    #   P1_pass <- as.matrix(expand.grid(P1_pass,unique(sharing_element)))
    # }else{
    #   P1_pass <- unique(t(combn(P1_possible_gamete,2)))
    # }
    # 
    # P2_possible_gamete <- P2_hap[P2_hap %in% row]
    # P2_pass <-  t(as.matrix(P2_possible_gamete[!P2_possible_gamete %in% sharing_element]))
    # if(length(P2_pass) == 0 & length(unique(P2_possible_gamete)) == 1) P2_pass <- t(as.matrix(P2_possible_gamete[1:2]))
    # if(length(P2_pass) != 2 & length(P2_pass) != 0){
    #   P2_pass <- as.matrix(expand.grid(P2_pass,unique(sharing_element)))
    # }else{
    #   P2_pass <- unique(t(combn(P2_possible_gamete,2)))
    # }
    
    
    # Total <- rbind(Total, result)
  }
  
  poly_list <- format_pairint_list(temp = poly_total)
  diso_list <- format_pairint_list(temp = diso_total)
  Total <- list()
  Total[['Polysomic']] <- poly_list
  Total[['Disomic']] <- diso_list
  return(Total)
}

#' identify the significance level of the mode of inheritance test results
#'
#' @param segregation_check results of mode of inheritance check (a list)
#' @param threshold significance threshold, default: 0.01. It means, when the threshold is less than 0.01, then this is significantly different from
#' mode of inheritance. 
#'
#' @return a dataframe record the determined mode of inheritance results for both parents of all markers.
#' The result can be {'Both', 'Disomic', 'Polysomic', 'Neither'}
#' @export
#'
#' @examples
inheritance_summary <- function(segregation_check = inheritance_check0,threshold = 0.01){
  temp <- do.call(rbind,lapply(names(segregation_check),function(i){
    # print(i)
    parent1 <- segregation_check[[i]]$P1
    parent2 <- segregation_check[[i]]$P2
    
    # if(class(parent1) == 'numeric') parent1 <- as.data.frame(t(as.matrix(parent1)))
    # if(class(parent2) == 'numeric') parent2 <- as.data.frame(t(as.matrix(parent2)))
    # 
    #P1
    parent1_diso <- sapply(names(parent1$diso),function(i){
      parent1$diso[[i]]$score
    })
    parent1_poly <- sapply(names(parent1$poly),function(i){
      parent1$poly[[i]]$score
    })
    parent1_diso <- parent1_diso[complete.cases(parent1_diso)]
    parent1_poly <- parent1_poly[complete.cases(parent1_poly)]
    
    if(!all(is.na(parent1_diso)) & !all(is.na(parent1_poly))){
      if(all(parent1_diso < threshold) & all(parent1_poly < threshold)){#not significant 
        P1_inheritance <- 'Neither'
      }else if(all(parent1_diso < threshold) & any(parent1_poly >= threshold)){
        P1_inheritance <- 'Polysomic'
      }else if (all(parent1_poly < threshold) & any(parent1_diso >= threshold)){
        P1_inheritance <- 'Disomic'
      }else{
        P1_inheritance <- 'Both'
      }
    }else{
      P1_inheritance <- NA
    }
    
    #P2
    parent2_diso <- sapply(names(parent2$diso),function(i){
      parent2$diso[[i]]$score
    })
    parent2_poly <- sapply(names(parent2$poly),function(i){
      parent2$poly[[i]]$score
    })
    parent2_diso <- parent2_diso[complete.cases(parent2_diso)]
    parent2_poly <- parent2_poly[complete.cases(parent2_poly)]
    
    if(!all(is.na(parent2_diso)) & !all(is.na(parent2_poly))){
      if(all(parent2_diso < threshold) & all(parent2_poly < threshold)){#not significant 
        P2_inheritance <- 'Neither'
      }else if(all(parent2_diso < threshold) & any(parent2_poly >= threshold)){
        P2_inheritance <- 'Polysomic'
      }else if (all(parent2_poly < threshold) & any(parent2_diso >= threshold)){
        P2_inheritance <- 'Disomic'
      }else{
        P2_inheritance <- 'Both'
      }}else{
        P2_inheritance <- NA
      }
    
    c(P1_inheritance,P2_inheritance)
  }))
  rownames(temp) <- names(segregation_check)
  colnames(temp) <- c('P1','P2')
  return(temp)
}


#' percentage of parent haplotype sharing percentage identification
#'
#' @param poly_list formated list of the mode of inheritance test format 
#' @param ploidy ploidy level
#'
#' @return a datafrane record all markers' sharing percentage 
#' @export
#'
#' @examples
sharing_identification <- function(poly_list = poly,ploidy = 4){
  check <- do.call(rbind,lapply(names(poly_list),function(m){
    parent_temp <- poly_list[[m]]$parent_info
    parent_temp <- apply(parent_temp,2,as.character)
    
    P1 <- c(parent_temp[1,])
    P2 <- c(parent_temp[2,])
    
    min(sum(P1 %in% P2),sum(P2 %in% P1))/4
  }))
  rownames(check) <- names(poly_list)
  colnames(check) <- 'sharing%'
  return(check)
}


#' marker type identification
#'
#' @param parent parent genotype
#'
#' @return turn the parent genotype of multi-allelic marker to a number. 
#' ABCD: 1_1_1_1
#' AABC: 1_1_2
#' AABB: 2_2
#' AAAB: 1_3
#' AAAA: 4
#' @export
#'
#' @examples
decide_MT <- function(parent = P1){
  allele <- strsplit(parent,'')[[1]]
  paste0(sort(table(allele)),collapse = "_")
}



#' wrap-up function to run mode of inheritance test
#'
#' @param ped pedigree file: a dataframe has three columns in the order: genotype, parent1, parent2
#' @param ncores number of cores would like to use to run the analysis 
#' @param polyhaplotyper_res result from polyhaplotyper
#' @param map genetic map of haploblocks. A dataframe include columns: marker, chromosome, position
#' @param ploidy crop ploidy level
#'
#' @return a list include all populations' mode of inheritance check result in the format of:
#'  - POP1
#'      *LG1: A dataframe have marker name as rows. 
#'            The columns include:
#'              marker: marker name
#'              chromosome: the chromosome it belongs to
#'              position: marker position in genetic map 
#'              sharing%: percentage of sharing haplotypes between two parents
#'              P1_MT, P2_MT: marker type of p1, p2, in the format of 1_1_1_1, 1_1_2, and etc.
#'              P1_0.05, P2_0.05, P1_0.01, P2_0.01: the mode of inheritance results of parent in different significance level
#'      *LG2
#'      *...
#'  - POP2
#'  - ...
#' @export
#'
#' @examples
MultiAllelic_Inheritance_Check <- function(ped,
                                           ncores = 6,
                                           polyhaplotyper_res = results,
                                           map = map,
                                           ploidy){
  pop_choice <- unique(paste0(ped[,2],'_',ped[,3]))
  pop_choice <- pop_choice[-1]
  examine_res <- list()
  for(comb in pop_choice){
    P1 <- strsplit(comb,'_')[[1]][1]
    P2 <- strsplit(comb,'_')[[1]][2]
    individuals <- as.character(ped[which(ped[,2] == P1 & ped[,3] == P2),1])
    
    #convert format
    poly <- format_polyhaplotyper_MMtest(haplotype_list = polyhaplotyper_res,
                                         ploidy = 4,
                                         Parent1 = P1,
                                         Parent2 = P2,
                                         individuals = individuals,
                                         filter_ind = NULL)
    #remove parent with missing values
    poly1 <- lapply(poly,function(contig){
      if(!any(is.na(contig$parent_info))){
        contig
      }else{
        NULL
      }})
    poly1[sapply(poly1, is.null)] <- NULL
    
    #run parallel function set up
    if("foreach" %in% rownames(installed.packages())){
      library(foreach)
    }else{
      install.packages('foreach')
      library(foreach)
    }
    
    if("doParallel" %in% rownames(installed.packages())){
      library(doParallel)
    }else{
      install.packages('doParallel')
      library(doParallel)
    }
    
    win <- Sys.info()["sysname"] == "Windows"
    if (win) {
      cl <- parallel::makeCluster(ncores)
      doSNOW::registerDoSNOW(cl)
    } else {
      doParallel::registerDoParallel(cores = ncores)
    }
    
    T1 <- Sys.time()
    inheritance_check <- foreach::foreach(i = seq_along(names(poly1)), .combine='c',.multicombine=FALSE,
                                          .export = c("gamete_probability_calcultion",
                                                      "create_gamete_polysomic",
                                                      'create_offspring',
                                                      "create_gamete_disomic",
                                                      'create_gamete_polysomic',
                                                      'Pair_count_segregation')) %dopar% {
                                                        mrk <- names(poly1)[i]
                                                        parent_score <- poly1[[mrk]]$parent_info
                                                        offspring_score <- poly1[[mrk]]$temp[-c(1,2),]
                                                        pair <- paste(do.call(paste0, as.data.frame(parent_score)),collapse = '_')
                                                        res <- Pair_count_segregation(pair,
                                                                                      F1 = offspring_score,
                                                                                      seg_invalidrate = 0.05)
                                                        list(res)
                                                      }
    names(inheritance_check) <- names(poly1)
    T2 <- Sys.time()
    
    # writeLines(paste0('It takes ', round(T2 - T1), ' seconds for mode of inheritance identification.'))
    
    #check each parent fitting which segregation 
    inheritance_P_0.05 <- inheritance_summary(segregation_check = inheritance_check,threshold = 0.05)
    colnames(inheritance_P_0.05) <- c('P1_0.05','P2_0.05')
    inheritance_P_0.01 <- inheritance_summary(segregation_check = inheritance_check,threshold = 0.01)
    colnames(inheritance_P_0.01) <- c('P1_0.01','P2_0.01')
    
    #check sharing percentage
    sharing_temp <- sharing_identification(poly_list = poly1,ploidy = 4)
    
    
    #find the marker type
    MT_temp <- do.call(rbind,lapply(poly1,function(mrk){
      poly1 <- mrk$parent_info
      poly1 <- apply(poly1,2,as.character)
      P1_MT <- decide_MT(parent = paste0(as.character(poly1[1,]),collapse = ''))
      P2_MT <- decide_MT(parent = paste0(as.character(poly1[2,]),collapse = ''))
      c(P1_MT,P2_MT)
    }))
    colnames(MT_temp) <- c('P1_MT','P2_MT')
    
    #Summary_table
    summary <- cbind(sharing_temp,MT_temp,inheritance_P_0.05,inheritance_P_0.01)
    summary <- as.data.frame(summary)
    examine_res[[comb]] <- summary
  }
  #put the LG and map location info into it
  examine_res_1 <- lapply(examine_res,function(res_pop){
    res_pop <- cbind(res_pop,map[rownames(res_pop),])
    res_pop1 <- lapply(unique(res_pop$chromosome),function(lg){
      res_pop[res_pop$chromosome %in% lg,]
    })
    names(res_pop1) <- paste0('LG',unique(res_pop$chromosome))
    res_pop1
  })
  return(examine_res_1)
}


#' plot_population
#'
#' @param res_list mode of inheritance result list. The structure of it looks like:
#' res_list:
#'  - POP1
#'      *LG1: A dataframe have marker name as rows. 
#'            The columns include:
#'              marker: marker name
#'              chromosome: the chromosome it belongs to
#'              position: marker position in genetic map 
#'              sharing%: percentage of sharing haplotypes between two parents
#'              P1_MT, P2_MT: marker type of p1, p2, in the format of 1_1_1_1, 1_1_2, and etc.
#'              P1_0.05, P2_0.05, P1_0.01, P2_0.01: the mode of inheritance results of parent in different significance level
#'      *LG2
#'      *...
#'  - POP2
#'  - ...
#' @param parent: target parent, either P1 or P2
#' @param map genetic map of haploblocks. A dataframe include columns: marker, chromosome, position
#'
#' @return
#' @export image of mode of inheritance test
#'
#' @examples
plot_population <- function(res_list,
                            parent = 'P1',
                            map = map){
  #plot lines within the chromosome
  plot_lines <- function(type = '2_2',
                         chrm.offset,
                         chrm.width,
                         tmp,
                         column = 'P2_MT',
                         col = 'green'){
    MT <- tmp[tmp[[column]] %in% c(type),]$position
    if(length(MT) > 1){
      for(i in seq(length(MT))){
        lines(c((chrm.offset - chrm.width), (chrm.offset + chrm.width)), c(MT[i], MT[i]), col = col)
      }
    }
  }
  
  graph_nbr <- length(unique(map$chromosome))
  if(graph_nbr > 1){
    par(mfrow = c(round(graph_nbr/2),2))
  }else{
    par(mfrow = c(1,1))
  }
  for(lg in unique(map$chromosome)){
    map_lg <- map[map$chromosome %in% lg,]
    
    max_position_chromosome <- max(map_lg$position)
    min_position_chromsome <- min(map_lg$position)
    
    #define the chromosome 
    min <- 0
    max <- round(max_position_chromosome + 20)
    axis_number <- seq(min,max,by=20)
    
    plot(NULL, ylim = c(0,round(max_position_chromosome+50)), xlim = c(0,8), yaxt = "n",
         bty = "n", 
         xaxt = "n",
         xlab = '', ylab ="", main = NULL)
    axis(side=2,at=axis_number)
    
    #draw chromosome out (how many population, then how many chromosome)
    for(j in seq_along(res_list)){
      chrm.width <- 0.08
      chrm.offset <- 0.1 + j - 1
      symbols(x= chrm.offset, y=min_position_chromsome, circles = chrm.width, bg="white", add=TRUE, inches = FALSE)
      symbols(x= chrm.offset, y=max_position_chromosome, circles = chrm.width, bg="white", add=TRUE, inches = FALSE)
      rect((chrm.offset - chrm.width), (min_position_chromsome - chrm.width) , (chrm.offset + chrm.width), (max_position_chromosome + chrm.width) , col = "white")
      
      #find the position I would like to draw in different colors
      column_chosen <- paste0(parent,'_0.01')
      # types <- c('Both','Polysomic','Neither','Disomic') #AABB, AABC, AAAB, AAAA, ABCD
      # col_choice <- c('blue','green','black','red')
      types <- c('Polysomic','Disomic')
      col_choice <- c('green','red')
      for(lt in seq_along(types)){
        plot_lines(type = types[lt],
                   chrm.offset,
                   chrm.width,
                   tmp = res_list[[j]][[paste0('LG',lg)]],
                   column = column_chosen,
                   col = col_choice[lt])
      }
    }
    axis(1, at=  0.1 + seq_along(res_list) - 1, labels= paste0('POP',seq_along(res_list)))
    title(main = paste0(parent,'- LG',lg) ,xlab = "Population", ylab = "Position(cM)")
    # legend('bottomright', legend= c('Polysomic','Disomic','Neither','Both') ,
    #        col=  c('green','red','black','blue'), lty=1, cex=0.8)
    legend('bottomright', legend= c('Polysomic','Disomic') ,
           col=  c('green','red'), lty=1, cex=0.8)
    par(new = FALSE)
  }
}
